import React, { useState, useEffect } from 'react'
import { db } from './firebase'
import { collection, addDoc, onSnapshot, serverTimestamp, query, orderBy } from 'firebase/firestore'

export default function App() {
  const [text, setText] = useState("")
  const [messages, setMessages] = useState([])

  useEffect(() => {
    const q = query(collection(db, "messages"), orderBy("time"))
    return onSnapshot(q, snap => {
      setMessages(snap.docs.map(d => d.data()))
    })
  }, [])

  const sendMessage = async () => {
    if (!text.trim()) return;
    await addDoc(collection(db, "messages"), {
      text,
      time: serverTimestamp()
    })
    setText("")
  }

  return (
    <div style={{ padding: 20 }}>
      <h1>Cloud Chat</h1>
      <div style={{ border: '1px solid #ccc', height: 250, overflowY: 'auto', padding: 10 }}>
        {messages.map((m, i) => <p key={i}>{m.text}</p>)}
      </div>
      <input value={text} onChange={e => setText(e.target.value)} placeholder="Message..." />
      <button onClick={sendMessage}>Send</button>
    </div>
  )
}